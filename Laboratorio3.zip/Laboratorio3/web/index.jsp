<%-- 
    Document   : index
    Created on : 27/08/2025, 15:30:16
    Author     : Clara Lopez
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="Style/Style.css"/>
        <title>Rompecabezas 4x4</title>
    </head>
    <body>
        <header>
            <div class="logoImage">
                <img src="Image/logo.jpg" alt="Logo"/>
                <span class="logo-text">PUZZLE</span>
            </div>
        </div>
    </header>
    <div class="contenedor-principal">
        <div class="container">
            <div class="title">
                <h2>Completa el rompecabezas antes de que finalize el tiempo</h2>
                <h1>Quezadas Puzzles</h1>
            </div>                
            <p>Selecciona la casilla vasia para poder moverse</p>
            <div class="puzzle" id="puzzle"></div>
            <p id="mensaje">Rompecabezas Iniciado</p>   
            <div class="content-buttons">
                <div class ="content-reset">
                    <img src="Image/reiniciar.png" alt="icon-reiniciar" id="reiniciarIcon" class="icon-reiniciar"/>               
                    <<img src="Image/info.jpg" class="icon-info" alt="Info" id="infoIcon" onclick="informacion()"/>

                </div>
                <div class="content-add">
                    <button class="btn" onclick="completarPuzzle()">COMPLETAR</button>           
                    <button class="btn" onclick="verificar()">VERIFICAR</button>           
                </div>
            </div>
        </div>
        <div class="info-container">
            <div class="time">
                <h2>Tiempo</h2>
                <p>Timpo maximo 90 segundos</p>
                <p id="reloj" class="reloj">00:00</p> 
            </div>
            <div class="img-puzzle">
                <h2>Imagen referente</h2>
                <img src="Image/rompecabezas.png" alt="rompecabesas referente" class="img-background"/>
            </div>
        </div>
    </div>
    <script src="JavaScript/myScript.js"></script>
    <div id="miModal" class="modal">
        <div class="modal-content">
            <h3 id="modalTitulo"></h3>
            <p id="modalMensaje"></p>
            <button onclick="cerrarModal()">Reiniciar</button>
        </div>
    </div>

</body>
</html>
