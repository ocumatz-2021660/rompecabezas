let puzzleContainer = document.getElementById('puzzle');
let mensaje = document.getElementById('mensaje');
let reloj = document.getElementById('reloj');
let imagen = 'Image/rompecabezas.png';

let piezas = Array.from({length: 16}, (_, i) => i);
let estado = [];
let tiempo = 0;
let intervalo;

function mezclar(array) {
    let copia = [...array];
    for (let i = copia.length - 1; i > 0; i--) {
        let j = Math.floor(Math.random() * (i + 1));
        [copia[i], copia[j]] = [copia[j], copia[i]];
    }
    return copia;
}

function dibujar() {
    puzzleContainer.innerHTML = "";
    estado.forEach((valor, i) => {
        let celda = document.createElement('div');
        celda.classList.add('celda');
        if (valor !== 15) {
            let x = (valor % 4) * 150;
            let y = Math.floor(valor / 4) * 150;
            celda.style.backgroundImage = `url(${imagen})`;
            celda.style.backgroundPosition = `-${x}px -${y}px`;
        } else {
            celda.classList.add('vacio');
        }
        celda.addEventListener('click', () => mover(i));
        puzzleContainer.appendChild(celda);
    });
}

function mover(indice) {
    let vacio = estado.indexOf(15);
    let filas = 4;
    let col = indice % filas;
    let fila = Math.floor(indice / filas);
    let colVacio = vacio % filas;
    let filaVacio = Math.floor(vacio / filas);

    if ((Math.abs(col - colVacio) === 1 && fila === filaVacio) ||
            (Math.abs(fila - filaVacio) === 1 && col === colVacio)) {
        [estado[indice], estado[vacio]] = [estado[vacio], estado[indice]];
        dibujar();
    }
}

function mostrarModal(titulo, msg) {
    document.getElementById("modalTitulo").innerText = titulo;
    document.getElementById("modalMensaje").innerText = msg;
    document.getElementById("miModal").style.display = "flex";
}

function cerrarModal() {
    document.getElementById("miModal").style.display = "none";
    reiniciar();
}
function completarPuzzle() {
    estado = [...piezas];  // ordenar las piezas en su estado final
    dibujar();             
    clearInterval(intervalo); 
    mensaje.innerHTML = "Rompecabezas completado automáticamente";
}

function verificar() {
    if (JSON.stringify(estado) === JSON.stringify(piezas)) {
        clearInterval(intervalo);
        mensaje.innerHTML = "¡Completado¡";
        mostrarModal("Felicidades", "No eres un robot");
        window.location.href = "https://www.youtube.com/shorts/rUT2mVgFYPs"; 
    } else {
        mostrarModal("Fallaste", "El rompecabezas esta incompleto (eres un robot)");
    }
}
function informacion(){
    mostrarModal(
        'CAPTCHA (No soy un robot)',
        'Este rompecabezas utiliza un CSS inspirado en los CAPTCHA que nos aparecen al navegar en internet'
    );
}


   

function iniciarCronometro() {
    tiempo = 0;
    clearInterval(intervalo);
    intervalo = setInterval(() => {
        tiempo++;
        let minutos = Math.floor(tiempo / 60);
        let segundos = tiempo % 60;
        reloj.textContent = `${minutos.toString().padStart(2, '0')}:${segundos.toString().padStart(2, '0')}`;
        if (tiempo >= 90) {
            clearInterval(intervalo);
            mensaje.innerHTML = "Tiempo agotado";
            mostrarModal("Fallaste", "Eres un robot ");
        }
        if(tiempo >= 60){
            reloj.style.color='#F5D400';
        }
        if (tiempo >= 75) {
            reloj.style.color='red';
            reloj.style.fontWeight='bold';
        }
    }, 1000);
}

function reiniciar() {
    document.getElementById('reiniciarIcon').addEventListener('click',reiniciar);
    estado = mezclar(piezas);
    mensaje.innerHTML = "Rompecabezas Iniciado";
    dibujar();
    iniciarCronometro();
    reloj.style.color='white';
    reloj.style.fontWeight='normal';
}

window.onload = () => reiniciar();
